 <p class="tishiwenzi">当前使用的免费版没有移动版功能，若你需要移动版功能可以查看付费版的功能，付费版此次开发了html5框架，对于移动版的兼容非常不错，你可以访问链接查看付费版的具体功能，也可以扫描下面的二维码查看付费版在移动设备上的显示效果<a target="_blank" href="http://www.themepark.com.cn/msscwordpressqyzt.html"> 查看付费版详情</a></p><br />

<p><img src="<?php echo get_bloginfo('template_url').'/images/magicparallax-WordPress-themepark_move.jpg';; ?>" /></p>



